from flask import Flask, render_template, request, flash, redirect, url_for
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import pickle


app = Flask(__name__)
app.secret_key = 'your_generated_hex_string_here' # you do not need to do here and leave like this

EMAIL_ADDRESS = "youremail@gmail.com"
EMAIL_PASSWORD = "your secure app password"  #not your email password, be one your two step verficiation and go https://myaccount.google.com/apppasswords and get 16 chars
RECEIVER_EMAIL = "youremail@gmail.com" # use same above email

with open('iris_model.pkl', 'rb') as file:
    model = pickle.load(file)


@app.route('/')
def home():
    return render_template("home.html")

@app.route('/predict', methods=["GET", "POST"])
def predict():
    prediction = None

    if request.method == "POST":
        features = [
            float(request.form["sepal_length"]),
            float(request.form["sepal_width"]),
            float(request.form["petal_length"]),
            float(request.form["petal_width"])
        ]

        result = model.predict([features])[0]
        class_names = ["setosa", "versicolor", "virginica"]
        prediction =class_names[result]

    return render_template("predict.html", prediction=prediction)

@app.route('/contact', methods=['GET'])
def contact():
    return render_template("contact.html")

@app.route('/contact', methods=['POST'])
def send_email():
    full_name = request.form['name']
    email = request.form['email']
    message = request.form['message']

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

        msg_admin = MIMEMultipart()
        msg_admin['From'] = EMAIL_ADDRESS
        msg_admin['To'] = RECEIVER_EMAIL
        msg_admin['Subject'] = f"New Contact Message from {full_name}"
        msg_admin['Reply-To'] = email   

        body_admin = f"""
        New message received:

        Name: {full_name}
        Email: {email}

        Message:
        {message}
        """

        msg_admin.attach(MIMEText(body_admin, 'plain'))
        server.send_message(msg_admin)

        msg_user = MIMEMultipart()
        msg_user['From'] = EMAIL_ADDRESS
        msg_user['To'] = email
        msg_user['Subject'] = "We received your message"

        body_user = f"""
        Dear {full_name},

        Thank you for contacting us.
        We have received your message and will respond personally as soon as possible.

        Best regards,
        Your Team
        """

        msg_user.attach(MIMEText(body_user, 'plain'))
        server.send_message(msg_user)

        server.quit()

        flash("Your message has been sent successfully!", "success")
        return redirect(url_for('contact'))

    except Exception as e:
        print(e)
        flash("Something went wrong. Please try again.", "danger")
        return redirect(url_for('contact'))

if __name__ == '__main__':
    app.run(debug=True)